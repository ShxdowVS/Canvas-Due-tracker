# Canvas Due Tracker

A Chrome (Manifest V3) extension that aggregates everything due from your
Canvas LMS account into one popup, organised by subject. Per-course source
toggles let you choose where each subject pulls from. Built in vanilla JS,
no token needed — uses your existing Canvas browser session.

## Features

- One collapsible card per active Canvas course
- Per-course source toggles:
  - **Announcements** — `/courses/{id}/discussion_topics?only_announcements=true`, scanned for due-date mentions
  - **To-Do** — `/users/self/todo`, filtered to that course
  - **Modules** — `/courses/{id}/modules?include[]=items&include[]=content_details`, walks every item with a `due_at`
  - **Get All** — turn on all three sources at once
- Aggregated, deduplicated, sorted-by-due task list per subject
- Check off tasks → fade out → persisted hidden across re-opens
- "Show completed" toggle, per-subject and global "Reset"
- Matte black UI with a single electric-lime accent (`#c6ff3d`)
- Custom animated checkbox, due-today left border, soft hover glow

## Installation (unpacked)

1. Open `chrome://extensions`
2. Top-right: enable **Developer mode**
3. Click **Load unpacked**
4. Choose the folder containing this README (`canvas-due-tracker/`)
5. The extension's puzzle-piece icon appears in your toolbar — pin it for easy access

## First-time setup

1. Click the extension icon → popup opens
2. Click the **gear** icon (top-right)
3. Enter your Canvas hostname — e.g. `canvas.instructure.com`
4. Click **Save**
5. If your Canvas isn't on `*.instructure.com`, Chrome will ask permission for your host — click Allow
6. Your active courses load
7. Click a course card to expand it; toggle the source pills to choose what to pull

You need to be **logged into Canvas in this Chrome profile** for the extension to fetch data — it uses your browser cookies, not an API token. If you see "Not signed in", open `https://<your-domain>` in a tab, log in, then hit refresh.

## File map

```
canvas-due-tracker/
├── manifest.json           Manifest V3 declaration
├── popup/
│   ├── popup.html          Toolbar popup markup
│   ├── popup.css           Black + lime styling
│   └── popup.js            Render logic, event wiring
├── background/
│   └── service-worker.js   Periodic course refresh
├── lib/
│   ├── canvas-api.js       Fetch wrappers + pagination
│   ├── storage.js          chrome.storage.local abstraction
│   └── parsers.js          HTML→text, due-date extraction, task shape, dedup
├── icons/                  (empty; Chrome falls back to default)
└── README.md
```

## How announcement due-date parsing works

`lib/parsers.js` runs a two-stage regex on the announcement's plain-text body:

1. **Trigger detection** — only proceed if the text contains a strong "due-being-announced" keyword: `due`, `deadline`, `submit`, `hand in`, `by <weekday/date>`, "before our next lesson".
2. **Phrase extraction + date parsing** — capture the chunk of text right after the trigger, then try (in order):
   - `Date.parse()` for ISO-ish or "March 21, 2026" style strings
   - "today" / "tomorrow" anchored to the announcement's `posted_at`
   - "(this|next) <weekday>" — pick the next occurrence after the post date

If no date is found, the announcement is skipped (kept noise low).

## Tweaking

Open `lib/parsers.js` to adjust the regex vocabulary or `popup.css` to change the colour palette — every colour lives in `:root` custom properties at the top of the file.

## Permissions

| Permission | Why |
|---|---|
| `activeTab` | Future: read the current Canvas tab to auto-fill the domain |
| `storage` | Cache course list, per-course settings, completed task IDs |
| `cookies` | Implicit via `credentials: 'include'` — uses your existing session |
| `alarms` | Hourly cached-course refresh in the background |
| `host_permissions: *://*.instructure.com/*` | Read your Canvas API |
| `optional_host_permissions: *://*/*` | Requested at runtime if your school uses a custom domain |

No data leaves your machine. The extension talks only to your Canvas server.

// Canvas Due Tracker — service worker.
//
// Lightweight: this extension is popup-driven, so the worker mostly idles.
// We do schedule a periodic alarm to optionally refresh the cached course
// list in the background (useful for keeping things warm).

import { getDomain, setCourses } from '../lib/storage.js';
import { fetchCourses } from '../lib/canvas-api.js';

const REFRESH_INTERVAL_MIN = 30;

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create('refresh-courses', { periodInMinutes: REFRESH_INTERVAL_MIN });
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'refresh-courses') await maybeRefreshCourses();
});

async function maybeRefreshCourses() {
  const domain = await getDomain();
  if (!domain) return;
  const r = await fetchCourses(domain);
  if (!r.error && r.data) await setCourses(r.data);
}

// Allow the popup to request a forced refresh.
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === 'refresh-courses') {
    maybeRefreshCourses().then(() => sendResponse({ ok: true }));
    return true;
  }
});

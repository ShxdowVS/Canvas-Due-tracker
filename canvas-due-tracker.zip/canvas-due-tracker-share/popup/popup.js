// Canvas Due Tracker — popup logic.
//
// Loads cached state instantly, then refreshes from Canvas on demand.
// Per-course source toggles drive which API endpoints are called when a
// course card is expanded. Completed tasks are persisted to chrome.storage
// so they stay hidden across popup re-opens.

import * as S from '../lib/storage.js';
import * as API from '../lib/canvas-api.js';
import * as P from '../lib/parsers.js';

const $  = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => root.querySelectorAll(sel);

const main          = $('#main');
const coursesView   = $('#courses-view');
const settingsView  = $('#settings-view');
const refreshBtn    = $('#refresh-btn');
const settingsBtn   = $('#settings-btn');
const saveBtn       = $('#save-settings-btn');
const domainInput   = $('#domain-input');
const showDone      = $('#show-completed-toggle');
const resetBtn      = $('#reset-completed-btn');
const settingsMsg   = $('#settings-status');

// In-memory snapshot to avoid re-reading storage during a single render pass.
const state = {
  domain: null,
  courses: [],
  courseSettings: {},   // { [courseId]: { announcements, todo, modules } }
  hiddenCourses: new Set(),  // course IDs the user has hidden from the main view
  completed: new Set(),
  showCompleted: false,
  // Per-course raw caches (avoid re-fetching the same endpoint multiple times)
  perCourseTasks: new Map(),  // courseId -> Task[]
  // Global caches (shared across courses)
  todoCache: null,
  plannerCache: null,
};

// Default per-course source config — Get All, on for new courses.
function defaultSourceConfig() {
  return { announcements: true, todo: true, modules: true };
}

// ---------- init ----------

const AUTO_REFRESH_AFTER_MS = 30 * 60 * 1000;

(async function init() {
  await loadAll();
  await migrateEnsureModulesOn();
  renderMain();
  wireHeader();
  wireSettings();
  // If the course list is older than 30 min, kick off a background refresh now.
  // The popup is already showing cached data; the refresh updates it in place.
  maybeAutoRefresh();
})();

async function maybeAutoRefresh() {
  const { lastCoursesFetch } = await chrome.storage.local.get(['lastCoursesFetch']);
  const stale = !lastCoursesFetch || (Date.now() - lastCoursesFetch) > AUTO_REFRESH_AFTER_MS;
  if (!stale) return;
  refreshBtn.classList.add('spinning');
  try {
    await refreshCourses();
    state.perCourseTasks.clear();
    state.todoCache = null;
    state.plannerCache = null;
    renderMain();
    await reExpandAll();
  } finally {
    setTimeout(() => refreshBtn.classList.remove('spinning'), 400);
  }
}

async function loadAll() {
  state.domain          = await S.getDomain();
  state.courses         = await S.getCourses();
  state.courseSettings  = await S.getCourseSettings();
  state.hiddenCourses   = await S.getHiddenCourses();
  state.completed       = await S.getCompleted();
  state.showCompleted   = await S.getShowCompleted();
  domainInput.value     = state.domain || '';
  showDone.checked      = state.showCompleted;
}

// One-time migration: ensure Modules is enabled on every existing
// per-course setting. Gated by a storage flag so it runs exactly once;
// after this, the user is free to toggle Modules off per card and we
// won't override their choice on subsequent loads.
async function migrateEnsureModulesOn() {
  const flag = await chrome.storage.local.get(['migration:modules-on-v1']);
  if (flag['migration:modules-on-v1']) return;
  let changed = false;
  for (const cid of Object.keys(state.courseSettings)) {
    const cur = state.courseSettings[cid];
    if (cur && cur.modules !== true) {
      cur.modules = true;
      changed = true;
    }
  }
  if (changed) await S.setCourseSettings(state.courseSettings);
  await chrome.storage.local.set({ 'migration:modules-on-v1': true });
}

// ---------- header buttons ----------

function wireHeader() {
  refreshBtn.addEventListener('click', async () => {
    refreshBtn.classList.add('spinning');
    try {
      await refreshCourses();
      // also force refresh of every currently-expanded course
      state.perCourseTasks.clear();
      state.todoCache = null;
    state.plannerCache = null;
      renderMain();
      await reExpandAll();
    } finally {
      setTimeout(() => refreshBtn.classList.remove('spinning'), 400);
    }
  });
  settingsBtn.addEventListener('click', () => toggleSettings());
}

function toggleSettings(forceOpen) {
  const isOpen = !settingsView.hidden;
  const open = forceOpen != null ? forceOpen : !isOpen;
  settingsView.hidden = !open;
  coursesView.hidden = open;
  settingsBtn.classList.toggle('active', open);
  if (open) renderHiddenCourses();
}

// ---------- settings view ----------

function wireSettings() {
  saveBtn.addEventListener('click', async () => {
    let d = domainInput.value.trim();
    d = d.replace(/^https?:\/\//, '').replace(/\/.*$/, '').replace(/\s+/g, '');
    if (!d) return showStatus('err', 'Please enter a Canvas hostname.');

    // Request optional host permission for non-instructure.com schools
    const pattern = `*://${d}/*`;
    if (!await chrome.permissions.contains({ origins: [pattern] })) {
      const granted = await chrome.permissions.request({ origins: [pattern] });
      if (!granted) return showStatus('err', `Permission for ${d} was denied.`);
    }
    state.domain = d;
    await S.setDomain(d);

    showStatus('ok', `Saved ${d}. Loading courses…`);
    const r = await API.fetchCourses(d);
    if (r.error) {
      if (r.status === 401) return showStatus('err', `Not logged in to ${d}. Open it in a tab, sign in, then try again.`);
      return showStatus('err', `Canvas error: ${r.error}`);
    }
    state.courses = r.data || [];
    await S.setCourses(state.courses);
    showStatus('ok', `Loaded ${state.courses.length} courses. Close this panel to view.`);
    renderMain();
  });

  showDone.addEventListener('change', async () => {
    state.showCompleted = showDone.checked;
    await S.setShowCompleted(state.showCompleted);
    renderMain();
    await reExpandAll();
  });

  resetBtn.addEventListener('click', async () => {
    if (!confirm('Reset every completed task? They will all reappear.')) return;
    await S.clearCompletedForCourse();
    state.completed = new Set();
    showStatus('ok', 'All completed tasks reset.');
    renderMain();
    await reExpandAll();
  });
}

function showStatus(kind, msg) {
  settingsMsg.className = 'status-msg show ' + kind;
  settingsMsg.textContent = msg;
}

// ---------- hidden-courses list (settings view) ----------

function renderHiddenCourses() {
  const el = document.getElementById('hidden-courses-list');
  if (!el) return;
  const hidden = state.courses.filter(c => state.hiddenCourses.has(c.id));
  if (!hidden.length) {
    el.innerHTML = `<div class="hidden-courses-empty">No courses hidden.</div>`;
    return;
  }
  el.innerHTML = hidden.map(c => `
    <div class="hidden-course-row">
      <span class="name">${escapeHtml(c.name || c.course_code || `Course ${c.id}`)}</span>
      <button class="show-btn" data-id="${c.id}">Show</button>
    </div>`).join('');
  el.querySelectorAll('.show-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = Number(btn.dataset.id);
      state.hiddenCourses.delete(id);
      await S.setHiddenCourses(state.hiddenCourses);
      renderHiddenCourses();
      renderMain();
    });
  });
}

// ---------- course list rendering ----------

function renderMain() {
  if (!state.domain) {
    coursesView.innerHTML = emptyCard(
      '⚙',
      'Set up your Canvas',
      'Click the gear icon and enter your Canvas hostname to get started.',
      'Open settings',
      () => toggleSettings(true),
    );
    return;
  }
  if (!state.courses.length) {
    coursesView.innerHTML = `
      <div class="skeleton skel-card"></div>
      <div class="skeleton skel-card"></div>
      <div class="skeleton skel-card"></div>`;
    // try to refresh in the background
    refreshCourses().then(() => renderMain());
    return;
  }
  const visible = state.courses.filter(c => !state.hiddenCourses.has(c.id));
  if (!visible.length) {
    coursesView.innerHTML = emptyCard(
      '◌',
      'No courses showing',
      'You\'ve hidden all of them. Open settings to bring some back.',
      'Open settings',
      () => toggleSettings(true),
    );
    return;
  }
  coursesView.innerHTML = visible.map(courseCardHtml).join('');
  for (const card of $$('.course-card')) wireCourseCard(card);
}

function courseCardHtml(course) {
  const cfg = state.courseSettings[course.id] || defaultSourceConfig();
  const courseName = course.name || course.course_code || `Course ${course.id}`;
  return `
    <article class="course-card" data-course-id="${course.id}">
      <header class="course-header">
        <svg class="chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="9 18 15 12 9 6"></polyline>
        </svg>
        <span class="course-title">${escapeHtml(courseName)}</span>
        <span class="task-count-badge zero" data-role="count">·</span>
        <button class="hide-btn" data-role="hide" title="Hide this course">×</button>
      </header>
      <div class="course-body">
        <div class="course-body-inner">
          <div class="sources" role="group" aria-label="Sources">
            <button class="source-pill ${cfg.announcements ? 'active' : ''}" data-src="announcements">Announcements</button>
            <button class="source-pill ${cfg.todo          ? 'active' : ''}" data-src="todo">To-Do</button>
            <button class="source-pill ${cfg.modules       ? 'active' : ''}" data-src="modules">Modules</button>
            <button class="source-pill get-all"            data-src="all">Get All</button>
          </div>
          <ul class="task-list" data-role="tasks">
            <li class="task-list-empty">Expand to load tasks.</li>
          </ul>
        </div>
      </div>
    </article>`;
}

function wireCourseCard(card) {
  const id = Number(card.dataset.courseId);
  const header = $('.course-header', card);
  const list   = $('[data-role="tasks"]', card);
  const pills  = $$('.source-pill', card);
  const hideBtn = $('[data-role="hide"]', card);

  header.addEventListener('click', async () => {
    const wasOpen = card.classList.contains('expanded');
    card.classList.toggle('expanded');
    if (!wasOpen) await loadCourseTasks(card, id, list);
  });

  if (hideBtn) {
    hideBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      state.hiddenCourses.add(id);
      await S.setHiddenCourses(state.hiddenCourses);
      card.classList.add('removing');
      setTimeout(() => {
        card.remove();
        // If the user emptied the list, re-render to show the empty-state.
        if (!$$('.course-card').length) renderMain();
      }, 300);
    });
  }

  for (const pill of pills) {
    pill.addEventListener('click', async (e) => {
      e.stopPropagation();
      const src = pill.dataset.src;
      const cfg = state.courseSettings[id] || defaultSourceConfig();
      if (src === 'all') {
        cfg.announcements = cfg.todo = cfg.modules = true;
      } else {
        cfg[src] = !cfg[src];
      }
      state.courseSettings[id] = cfg;
      await S.setCourseSettings(state.courseSettings);
      $$('.source-pill', card).forEach(p => {
        if (p.dataset.src === 'all') return;
        p.classList.toggle('active', !!cfg[p.dataset.src]);
      });
      // Re-fetch when sources change
      state.perCourseTasks.delete(id);
      if (card.classList.contains('expanded')) {
        await loadCourseTasks(card, id, list);
      }
    });
  }
}

async function loadCourseTasks(card, courseId, listEl) {
  const course = state.courses.find(c => c.id === courseId);
  if (!course) return;
  const cfg = state.courseSettings[courseId] || defaultSourceConfig();

  // Show skeletons while loading
  listEl.innerHTML = `
    <li class="skeleton skel-card" style="height:42px;margin-bottom:6px"></li>
    <li class="skeleton skel-card" style="height:42px;margin-bottom:6px"></li>
    <li class="skeleton skel-card" style="height:42px;margin-bottom:0"></li>`;

  let tasks = state.perCourseTasks.get(courseId);
  if (!tasks) {
    tasks = await fetchCourseTasks(course, cfg);
    state.perCourseTasks.set(courseId, tasks);
  }

  // Apply filters
  const visible = tasks.filter(t => state.showCompleted || !state.completed.has(t.id));
  const sorted = P.sortByDue(visible);
  renderTaskList(listEl, sorted);
  updateBadge(card, sorted.length);
}

async function fetchCourseTasks(course, cfg) {
  // Always pre-fetch /todo — needed for filtering undated module items
  // and for the "still actionable" check.
  if (!state.todoCache) {
    const r = await API.fetchTodo(state.domain);
    state.todoCache = r.error ? [] : (r.data || []);
  }
  const todoAssignmentIds = new Set();
  for (const t of state.todoCache) {
    if (t.type === 'submitting' && t.assignment) todoAssignmentIds.add(t.assignment.id);
  }

  // Fetch submission state for THIS course (used for auto-tick).
  // We always do this so submissions sync on every refresh.
  const subResp = await API.fetchAssignmentsWithSubmission(state.domain, course.id);
  const submittedIds = new Set();
  if (!subResp.error && subResp.data) {
    for (const a of subResp.data) {
      const sub = a.submission || {};
      if (['submitted', 'graded', 'pending_review'].includes(sub.workflow_state)) {
        submittedIds.add(a.id);
      }
    }
  }

  const calls = [];
  if (cfg.announcements) calls.push(loadAnnouncements(course));
  if (cfg.todo)          calls.push(loadTodoFor(course));
  if (cfg.modules)       calls.push(loadModules(course));
  const results = await Promise.all(calls);
  const merged = P.dedupeTasks([].concat(...results));

  let completedChanged = false;

  // STALE-TICK CLEANUP: anything currently on Canvas's /todo must be visible.
  // We delete BOTH possible prefixed forms (`todo:NNN`, `mod:NNN`) because
  // earlier auto-tick may have stored either, depending on which source won
  // the dedup at the time it was written.
  for (const task of merged) {
    const m = task.id.match(/^(?:mod|todo):(\d+)$/);
    if (!m) continue;
    const aid = Number(m[1]);
    if (!todoAssignmentIds.has(aid)) continue;
    if (state.completed.delete(`todo:${aid}`)) completedChanged = true;
    if (state.completed.delete(`mod:${aid}`))  completedChanged = true;
  }

  // AUTO-TICK: assignments Canvas marks submitted/graded AND that are no
  // longer on /todo are safe to hide. /todo is the authoritative signal.
  for (const task of merged) {
    const m = task.id.match(/^(?:mod|todo):(\d+)$/);
    if (!m) continue;
    const aid = Number(m[1]);
    if (todoAssignmentIds.has(aid)) continue;
    if (submittedIds.has(aid) && !state.completed.has(task.id)) {
      state.completed.add(task.id);
      completedChanged = true;
    }
  }

  if (completedChanged) await S.setCompleted(state.completed);

  return merged;
}

async function loadAnnouncements(course) {
  const r = await API.fetchAnnouncements(state.domain, course.id);
  if (r.error) return [];
  return P.announcementsToTasks(r.data, course);
}

async function loadTodoFor(course) {
  // Fetch both /todo (legacy) and /planner/items (what the Canvas
  // dashboard's "To Do" widget reads from). Merge them; dedupeTasks
  // handles the overlap.
  if (!state.todoCache) {
    const r = await API.fetchTodo(state.domain);
    state.todoCache = r.error ? [] : (r.data || []);
  }
  if (!state.plannerCache) {
    const r = await API.fetchPlanner(state.domain);
    state.plannerCache = r.error ? [] : (r.data || []);
  }
  return [
    ...P.todoToTasks(state.todoCache, course),
    ...P.plannerToTasks(state.plannerCache, course),
  ];
}

async function loadModules(course) {
  const r = await API.fetchModules(state.domain, course.id);
  if (r.error) return [];
  return P.modulesToTasks(r.data, course);
}

// ---------- task rendering ----------

function renderTaskList(listEl, tasks) {
  if (!tasks.length) {
    listEl.innerHTML = `<li class="task-list-empty">All caught up.</li>`;
    return;
  }
  listEl.innerHTML = tasks.map(taskHtml).join('');
  for (const t of $$('.task', listEl)) wireTask(t);
}

function taskHtml(t) {
  const done = state.completed.has(t.id);
  const dueState = P.dueState(t.due);
  const dueText  = P.formatDue(t.due);
  const todayClass = dueState === 'today' ? 'today' : '';
  return `
    <li class="task ${done ? 'done' : ''} ${todayClass}" data-id="${escapeAttr(t.id)}">
      <input type="checkbox" class="task-check" ${done ? 'checked' : ''} aria-label="Mark complete">
      <div class="task-info">
        <div class="task-title"><a href="${escapeAttr(t.url)}" target="_blank" rel="noopener">${escapeHtml(t.title)}</a></div>
        <div class="task-meta">
          <span class="task-due ${dueState}">${escapeHtml(dueText)}</span>
          <span class="source-badge">${escapeHtml(t.source)}</span>
        </div>
      </div>
    </li>`;
}

function wireTask(li) {
  const id = li.dataset.id;
  const cb = $('.task-check', li);
  cb.addEventListener('click', (e) => e.stopPropagation());
  cb.addEventListener('change', async () => {
    if (cb.checked) {
      await S.markCompleted(id);
      state.completed.add(id);
      if (!state.showCompleted) {
        // animate out then remove
        li.classList.add('removing');
        setTimeout(() => {
          li.remove();
          const list = li.closest('.task-list');
          if (list && !list.children.length) {
            list.innerHTML = `<li class="task-list-empty">All caught up.</li>`;
          }
          const card = li.closest('.course-card');
          if (card) {
            const remaining = $$('.task', card).length;
            updateBadge(card, remaining);
          }
        }, 300);
      } else {
        li.classList.add('done');
      }
    } else {
      await S.unmarkCompleted(id);
      state.completed.delete(id);
      li.classList.remove('done');
    }
  });
}

function updateBadge(card, count) {
  const badge = $('[data-role="count"]', card);
  if (!badge) return;
  badge.textContent = count > 0 ? count : '·';
  badge.classList.toggle('zero', count === 0);
}

// ---------- refresh all open cards (after manual refresh) ----------

async function reExpandAll() {
  const open = $$('.course-card.expanded');
  for (const card of open) {
    const id = Number(card.dataset.courseId);
    const list = $('[data-role="tasks"]', card);
    await loadCourseTasks(card, id, list);
  }
}

// ---------- top-level course refresh ----------

async function refreshCourses() {
  if (!state.domain) return;
  const r = await API.fetchCourses(state.domain);
  if (r.error) {
    if (r.status === 401) {
      coursesView.innerHTML = emptyCard(
        '!',
        'Not signed in',
        `Open https://${escapeHtml(state.domain)} in a Chrome tab and log in, then come back here.`,
      );
    }
    return;
  }
  state.courses = r.data || [];
  await S.setCourses(state.courses);
  await chrome.storage.local.set({ lastCoursesFetch: Date.now() });
}

// ---------- empty card helper ----------

function emptyCard(icon, title, body, btnLabel, onClick) {
  const btn = btnLabel ? `<button class="empty-btn" id="empty-action-btn">${escapeHtml(btnLabel)}</button>` : '';
  setTimeout(() => {
    const b = document.getElementById('empty-action-btn');
    if (b && onClick) b.addEventListener('click', onClick);
  }, 0);
  return `
    <div class="empty-state">
      <div class="icon">${escapeHtml(icon)}</div>
      <h3>${escapeHtml(title)}</h3>
      <p>${body}</p>
      ${btn}
    </div>`;
}

// ---------- utilities ----------

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
}
function escapeAttr(s) { return escapeHtml(s); }
